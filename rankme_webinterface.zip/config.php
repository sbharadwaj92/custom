<?php
/* 
=====================================================
				MENSAGENS DE ERRO
=====================================================
*/
$msg[0] = "Conex�o com o banco falhou!";
$msg[1] = "N�o foi poss�vel selecionar o banco de dados!";
/*
=====================================================
					CONEXAO
=====================================================
*/

$sqlite_server = true; // ARE YOUR SERVER RUNNING THE PLUGIN AS SQLITE?

//(IF THE PLUGIN IS RUNNING AS MYSQL, PUT BELOW THE DATA FOR CONNECTING TO THE DATABASE THAT IS BEING USED BY THE PLUGIN)
$bd_user = ""; // DATABASE USER 
$bd_password = "";// DATABASE PASS
$bd = "";// DATABASE
$host = "";	// DATABASE HOST
$bd_table = ""; // DATABASE TABLE BEING USED AT THE PLUGIN. (rankme_sql_table cvar). Default: rankme.

$ftp_server = ""; //FTP HOST
$ftp_user_name = ""; // FTP USER NAME
$ftp_user_pass = ""; // FTP PASS
$ftpDIR = ""; // CSTRIKE FOLDER ON FTP

// Fazendo a conex�o com o servidor MySQL
$conexao = mysql_pconnect($host,$bd_user,$bd_password) or die($msg[0]);
mysql_select_db($bd,$conexao) or die($msg[1]);
?>
