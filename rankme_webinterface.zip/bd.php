<?php
/* 
=====================================================
				MENSAGENS DE ERRO
=====================================================
*/
$msg[0] = "Conex�o com o banco falhou!";
$msg[1] = "N�o foi poss�vel selecionar o banco de dados!";
/*
=====================================================
					CONEXAO
=====================================================
*/
$bd_user = ""; // DATABASE USER
$bd_password = "";// DATABASE PASS
$bd = "";// DATABASE
$host = "";	// DATABASE HOST


$lastback = file_get_contents("up/restore.txt");
	if(intval($lastback)+180 < mktime()){
		include "restore.php";
		
		file_put_contents("up/restore.txt",mktime());
	}
// Fazendo a conex�o com o servidor MySQL
$conexao = mysql_pconnect($host,$bd_user,$bd_password) or die($msg[0]);
mysql_select_db($bd,$conexao) or die($msg[1]);
?>
